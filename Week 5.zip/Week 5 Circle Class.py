import math

class Circle:
    pi = math.pi

    def __init__(self, radius, color):
        self.radius = radius
        self.color = color

    def getColor(self):
        return self.color
    
    def getCircum(self):
        return 2 * Circle.pi * self.radius
    
# example:
circle = Circle(37, 'Orange')
print('Color:', circle.getColor()) # output should be Orange
print('Circumference:', circle.getCircum()) # output should be around 232.48