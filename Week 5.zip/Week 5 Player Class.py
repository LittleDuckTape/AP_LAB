class Player:
    def __init__(self, name, initial_money=100, initial_health=100):
        self.name = name
        self.money = initial_money
        self.health = initial_health
        self.inventory = {}

    # inventory system
    def addItem(self, item, quantity):
        if item in self.inventory:
            self.inventory[item] += quantity
        else:
            self.inventory[item] = quantity
        print(f'{quantity} {item}(s) have been added to your inventory.')

    def removeItem(self, item, quantity):
        if item in self.inventory and self.inventory[item] >= quantity:
            self.inventory[item] -= quantity
            if self.inventory[item] == 0:
                del self.inventory[item]
            print(f'{quantity} {item}(s) have been removed from your inventory.')
        else:
            print(f'Not enough {item}(s) in your inventory to remove.')

    # money system
    def addMoney(self, amount):
        self.money += amount
        print(f'{amount}G added. Current balance: {self.money}G.')
    
    def spendMoney(self, amount):
        if self.money >= amount:
            self.money -= amount
            print(f'{amount}G spent. Current balance: {self.money}G.')
        else:
            print(f'Not enough Gold.')

    # health system
    def takeDamage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.health = 0
            self.checkStatus()
        else:
            print(f'{self.name} has taken {amount} damage. Current HP: {self.health}.')
    
    def checkStatus(self):
        if self.health == 0:
            print(f'{self.name} is dead.')

    def heal(self, amount):
        self.health += amount
        print(f'{self.name} is healed by {amount}HP. Current HP: {self.health}')

# example:
player = Player(name='Himmel')

player.addItem('Potion', 3)
player.addItem('Sword', 1)
player.removeItem('Potion', 1)

player.addMoney(50)
player.spendMoney(70)

player.takeDamage(20)
player.takeDamage(100)
player.heal(65)